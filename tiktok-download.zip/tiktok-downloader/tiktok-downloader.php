<?php
/*
Plugin Name: TikTok Video Preview & Downloader (Enhanced)
Description: Preview TikTok videos using oEmbed, show metadata, offer download links, and track interactions.
Version: 2.0
Author: Your Name
*/

function tiktok_downloader_enqueue_scripts() {
    wp_enqueue_script('jquery');
    wp_enqueue_script('tiktok-downloader-ajax', plugin_dir_url(__FILE__) . 'ajax.js', array('jquery'), null, true);
    wp_localize_script('tiktok-downloader-ajax', 'tiktok_ajax_obj', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('tiktok_downloader_nonce')
    ));
}
add_action('wp_enqueue_scripts', 'tiktok_downloader_enqueue_scripts');

function tiktok_downloader_shortcode() {
    ob_start();
    ?>
    <div id="tiktok-downloader">
        <input type="text" id="tiktok-url" placeholder="Enter TikTok video URL" style="width: 100%; padding: 10px;">
        <button id="tiktok-submit" style="margin-top: 10px; padding: 10px 20px;">Preview & Download</button>
        <div id="tiktok-result" style="margin-top: 20px;"></div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('tiktok_downloader', 'tiktok_downloader_shortcode');

function tiktok_downloader_ajax_handler() {
    check_ajax_referer('tiktok_downloader_nonce', 'nonce');

    $url = esc_url($_POST['url']);
    $cache_key = 'tiktok_oembed_' . md5($url);
    $cached = get_transient($cache_key);

    if ($cached) {
        $data = $cached;
    } else {
        $api_url = "https://www.tiktok.com/oembed?url=" . urlencode($url);
        $response = wp_remote_get($api_url);

        if (is_wp_error($response)) {
            wp_send_json_error('Error fetching video data.');
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body);
        set_transient($cache_key, $data, 12 * HOUR_IN_SECONDS);
    }

    if (!empty($data->html)) {
        // Track view
        $views = get_option('tiktok_views', array());
        $views[$url] = isset($views[$url]) ? $views[$url] + 1 : 1;
        update_option('tiktok_views', $views);

        ob_start();
        echo "<div style='border:1px solid #ddd; padding:15px; border-radius:8px; background:#f9f9f9;'>";
        echo "<h3>🎬 Video Preview:</h3>" . $data->html;
        echo "<h4>📄 Video Info:</h4>";
        echo "<p><strong>Title:</strong> " . esc_html($data->title) . "</p>";
        echo "<p><strong>Author:</strong> <a href='" . esc_url($data->author_url) . "' target='_blank'>" . esc_html($data->author_name) . "</a></p>";
        if (!empty($data->thumbnail_url)) {
            echo "<h4>🖼️ Thumbnail:</h4>";
            echo "<img src='" . esc_url($data->thumbnail_url) . "' alt='Thumbnail' style='max-width:100%; border-radius:6px;'>";
        }
        echo "<h4>⬇️ Download:</h4>";
        echo "<p><a href='" . esc_url($url) . "' target='_blank'>Download from TikTok (with watermark)</a></p>";
        echo "<p><em>Views tracked: " . $views[$url] . "</em></p>";
        echo "</div>";
        wp_send_json_success(ob_get_clean());
    } else {
        wp_send_json_error('Invalid TikTok URL or no preview available.');
    }
}
add_action('wp_ajax_tiktok_downloader', 'tiktok_downloader_ajax_handler');
add_action('wp_ajax_nopriv_tiktok_downloader', 'tiktok_downloader_ajax_handler');
