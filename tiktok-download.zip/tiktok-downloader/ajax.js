jQuery(document).ready(function($) {
    $('#tiktok-submit').click(function(e) {
        e.preventDefault();
        var url = $('#tiktok-url').val();
        $('#tiktok-result').html('<p>Loading preview...</p>');

        $.ajax({
            type: 'POST',
            url: tiktok_ajax_obj.ajax_url,
            data: {
                action: 'tiktok_downloader',
                nonce: tiktok_ajax_obj.nonce,
                url: url
            },
            success: function(response) {
                if (response.success) {
                    $('#tiktok-result').html(response.data);
                } else {
                    $('#tiktok-result').html('<p>' + response.data + '</p>');
                }
            },
            error: function() {
                $('#tiktok-result').html('<p>Something went wrong. Try again.</p>');
            }
        });
    });
});
